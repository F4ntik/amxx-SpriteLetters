/**
 * [SprLett] Editor
 */

#include <amxmodx>
#include <reapi>
#include <fakemeta>
#include <vector>
#include <SprLetters>
#include <SprLett-Gaming>
#include "SprLett-Core/Ver"

#pragma semicolon 1

#define nullent 0

#define EDIT_ACCESS ADMIN_RCON
new const MOVESTEP_VALUES[] = {1, 5, 10, 25, 50};

new const SELECT_CMD[] = "slselect";
new const CREATE_CMD[] = "slcreate";
new const EDITMODE_CMD[] = "sleditmode";

new const STEP_CMD[] = "slsetstep";
new const STEPEX_CMD[] = "slsetstepex";

new const MOVE_CMD[] = "slmove";
new const ROTATE_CMD[] = "slrotate";
new const ROTATE_MODE_CMD[] = "slrotatemode";
new const DIR_CMD[] = "sldir";

new const CHARSET_CMD[] = "slcharset";
new const OFFSET_CMD[] = "sloffset";
new const WRITE_CMD[] = "slwrite";
new const REMOVE_CMD[] = "slremove";
new const SAVE_CMD[] = "slsave";

new const RENDER_TYPE_CMD[] = "slrendtype";
new const RENDER_TYPE_EX_CMD[] = "slrendtypeex";
new const ALPHA_CMD[] = "slalpha";
new const COLOR_CMD[] = "slcolor";

new const MARQUEE_MENU_CMD[] = "slmarqueemenu";
new const MARQUEE_TOGGLE_CMD[] = "slmarqueetoggle";
new const MARQUEE_SETID_CMD[] = "slmarqueeid";
new const MARQUEE_SETWIDTH_CMD[] = "slmarqueewidth";
new const MARQUEE_SETSPEED_CMD[] = "slmarqueespeed";
new const MARQUEE_SETTEXT_CMD[] = "slmarqueetext";
new const MARQUEE_RESET_OFFSET_CMD[] = "slmarqueeoffset";

const DEFAULT_MARQUEE_WIDTH = 10;
const Float:DEFAULT_MARQUEE_SPEED = 5.0;

new const PLUG_NAME[] = "[SprLett] Editor";
#define PLUG_VER SPRLETT_VERSION

new gSelWord[MAX_PLAYERS + 1] = {nullent, ...};
new Float:gMoveStep[MAX_PLAYERS + 1] = {1.0, ...};

SyncWordDirWithAngles(const WordEnt){
    if(!SprLett_Is(WordEnt, SL_Is_Word))
        return;

    new Float:Angles[3];
    get_entvar(WordEnt, var_angles, Angles);

    new Float:Right[3];
    angle_vector(Angles, ANGLEVECTOR_RIGHT, Right);

    new Float:DirAngles[3];
    vector_to_angle(Right, DirAngles);
    set_entvar(WordEnt, var_SL_WordDir, DirAngles);
}

FindWordByAim(const UserId){
    new Float:Eye[3];
    get_entvar(UserId, var_origin, Eye);
    new Float:ViewOfs[3];
    get_entvar(UserId, var_view_ofs, ViewOfs);
    for(new i = 0; i < 3; i++)
        Eye[i] += ViewOfs[i];

    new Float:Angles[3];
    get_entvar(UserId, var_v_angle, Angles);

    new Float:Forward[3];
    angle_vector(Angles, ANGLEVECTOR_FORWARD, Forward);

    new WordEnt = nullent;
    new Float:BestAlong = 0.0;
    new Float:BestDistSq = 0.0;
    new bool:HaveCandidate = false;

    new LetterEnt = -1;
    while((LetterEnt = rg_find_ent_by_class(LetterEnt, "SprLetters_Letter")) > 0){
        if(!SprLett_Is(LetterEnt, SL_Is_Letter))
            continue;

        new EntWord = get_entvar(LetterEnt, var_SL_WordEnt);
        if(!SprLett_Is(EntWord, SL_Is_Word))
            continue;

        if(get_entvar(LetterEnt, var_effects) & EF_NODRAW)
            continue;

        new Float:LetterPos[3];
        get_entvar(LetterEnt, var_origin, LetterPos);

        new Float:Delta[3];
        for(new i = 0; i < 3; i++)
            Delta[i] = LetterPos[i] - Eye[i];

        new Float:Along = Delta[0]*Forward[0] + Delta[1]*Forward[1] + Delta[2]*Forward[2];
        if(Along <= 0.0)
            continue;

        new Float:Cross[3];
        Cross[0] = Delta[1]*Forward[2] - Delta[2]*Forward[1];
        Cross[1] = Delta[2]*Forward[0] - Delta[0]*Forward[2];
        Cross[2] = Delta[0]*Forward[1] - Delta[1]*Forward[0];

        new Float:DistSq = Cross[0]*Cross[0] + Cross[1]*Cross[1] + Cross[2]*Cross[2];

        new Float:LetterSize = get_entvar(EntWord, var_SL_LetterSize);
        new Float:MaxRadius = floatmax(LetterSize * 1.25, 4.0);
        if(DistSq > MaxRadius * MaxRadius)
            continue;

        if(!HaveCandidate || Along < BestAlong || (Along == BestAlong && DistSq < BestDistSq)){
            HaveCandidate = true;
            BestAlong = Along;
            BestDistSq = DistSq;
            WordEnt = EntWord;
        }
    }

    return HaveCandidate ? WordEnt : nullent;
}

#include "SprLett-Editor/Utils"
#include "SprLett-Editor/Menus"

public plugin_init(){
    register_plugin(PLUG_NAME, PLUG_VER, "ArKaNeMaN");
    register_dictionary("SpriteLetters.ini");

    RegisterClCmds(CREATE_CMD, "@Cmd_Create");
    RegisterClCmds(SELECT_CMD, "@Cmd_Select");
    RegisterClCmds(EDITMODE_CMD, "@Cmd_EditMode");

    RegisterClCmds(STEP_CMD, "@Cmd_SetStep");
    RegisterClCmds(STEPEX_CMD, "@Cmd_SetStepEx");

    RegisterClCmds(MOVE_CMD, "@Cmd_Move");
    RegisterClCmds(ROTATE_CMD, "@Cmd_Rotate");
    RegisterClCmds(ROTATE_MODE_CMD, "@Cmd_RotateMode");
    RegisterClCmds(DIR_CMD, "@Cmd_Dir");

    RegisterClCmds(CHARSET_CMD, "@Cmd_Charset");
    RegisterClCmds(OFFSET_CMD, "@Cmd_Offset");
    RegisterClCmds(WRITE_CMD, "@Cmd_Write");
    RegisterClCmds(REMOVE_CMD, "@Cmd_Remove");
    RegisterClCmds(SAVE_CMD, "@Cmd_Save");

    RegisterClCmds(RENDER_TYPE_CMD, "@Cmd_RenderType");
    RegisterClCmds(RENDER_TYPE_EX_CMD, "@Cmd_RenderTypeEx");
    RegisterClCmds(ALPHA_CMD, "@Cmd_Alpha");
    RegisterClCmds(COLOR_CMD, "@Cmd_Color");
    RegisterClCmds(MARQUEE_MENU_CMD, "@Cmd_MarqueeMenu");
    RegisterClCmds(MARQUEE_TOGGLE_CMD, "@Cmd_MarqueeToggle");
    RegisterClCmds(MARQUEE_SETID_CMD, "@Cmd_MarqueeSetId");
    RegisterClCmds(MARQUEE_SETWIDTH_CMD, "@Cmd_MarqueeSetWidth");
    RegisterClCmds(MARQUEE_SETSPEED_CMD, "@Cmd_MarqueeSetSpeed");
    RegisterClCmds(MARQUEE_SETTEXT_CMD, "@Cmd_MarqueeSetText");
    RegisterClCmds(MARQUEE_RESET_OFFSET_CMD, "@Cmd_MarqueeResetOffset");

    RegisterClCmds("slemoji", "@Cmd_EmojiMenu");
    MenuCmds_Init();
}

stock bool:ReadCommandText(const CmdName[], buffer[], const maxLen, const bool:TrimSpaces = false){
    buffer[0] = EOS;

    new args[WORD_MAX_LENGTH];
    read_args(args, charsmax(args));
    remove_quotes(args);

    if(args[0]){
        new cmdToken[64];
        formatex(cmdToken, charsmax(cmdToken), "/%s", CmdName);
        new tokenLen = strlen(cmdToken);
        if(strlen(args) >= tokenLen && equali(args, cmdToken, tokenLen)){
            new start = tokenLen;
            if(args[start] == ' ')
                start++;
            formatex(buffer, maxLen, "%s", args[start]);
        } else {
            copy(buffer, maxLen, args);
        }

        if(TrimSpaces)
            MarqueeEditor_TrimString(buffer, maxLen);
        return buffer[0] != EOS;
    }

    new nullArg = GetNullArg();
    new argc = read_argc();
    new arg[128];
    new bool:started = false;

    for(new i = nullArg + 1; i < argc; i++){
        read_argv(i, arg, charsmax(arg));
        if(i == nullArg + 1){
            if(equali(arg, CmdName) || equali(arg, fmt("/%s", CmdName)))
                continue;
        }
        if(started)
            add(buffer, maxLen, " ");
        add(buffer, maxLen, arg);
        started = true;
    }

    if(TrimSpaces)
        MarqueeEditor_TrimString(buffer, maxLen);
    return buffer[0] != EOS;
}

@Cmd_Color(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 3)
    CHECK_WORD(UserId)

    new Float:Color[3], Float:Previous[3];
    get_entvar(gSelWord[UserId], var_rendercolor, Color);
    get_entvar(gSelWord[UserId], var_rendercolor, Previous);
    Color[0] = floatclamp(Color[0] + read_argv_float(NULL_ARG+1), 0.0, 255.0);
    Color[1] = floatclamp(Color[1] + read_argv_float(NULL_ARG+2), 0.0, 255.0);
    Color[2] = floatclamp(Color[2] + read_argv_float(NULL_ARG+3), 0.0, 255.0);
    set_entvar(gSelWord[UserId], var_rendercolor, Color);
    if(!SprLett_RebuildWord(gSelWord[UserId])){
        set_entvar(gSelWord[UserId], var_rendercolor, Previous);
        ReportBuildError(UserId);
    }
}

@Cmd_RenderType(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)
    
    set_entvar(gSelWord[UserId], var_rendermode, clamp(read_argv_int(NULL_ARG+1), kRenderNormal, kRenderTransAdd));

    SprLett_RebuildWord(gSelWord[UserId]);
}

@Cmd_RenderTypeEx(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CHECK_WORD(UserId)

    new RendType = get_entvar(gSelWord[UserId], var_rendermode);
    RendType++;
    if(RendType > kRenderTransAdd)
        RendType = kRenderNormal;

    client_cmd(UserId, fmt("%s %d", RENDER_TYPE_CMD, RendType));
}

@Cmd_Alpha(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new Float:Alpha = Float:get_entvar(gSelWord[UserId], var_renderamt);
    Alpha = floatclamp(Alpha + read_argv_float(NULL_ARG+1), 0.0, 255.0);
    set_entvar(gSelWord[UserId], var_renderamt, Alpha);
    
    SprLett_RebuildWord(gSelWord[UserId]);
}

@Cmd_EditMode(const UserId){
    CMD_CHECK_ACCESS(UserId)
    
    SprLett_SetEditMode(!SprLett_GetEditMode());

    client_print(UserId, print_center, "%l", "CMD_EDIT_MODE", SprLett_GetEditMode() ? Lang("CMDS_ENABLED") : Lang("CMDS_DISABLED"));
}

@Cmd_Create(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)

    new Word[WORD_MAX_LENGTH];
    ReadCommandText(CREATE_CMD, Word, charsmax(Word));

    new Float:UserOrigin[3];
    get_entvar(UserId, var_origin, UserOrigin);
    UserOrigin[2] += 75.0;

    new Float:UserAngles[3];
    get_entvar(UserId, var_v_angle, UserAngles);
    UserAngles[2] = 0.0;
    UserAngles[0] = 0.0;

    new Float:Dir[3];
    Dir[0] = UserAngles[0];
    Dir[1] = UserAngles[1] - 90.0;
    Dir[2] = UserAngles[2];

    SprLett_SetParams(
        SL_P_Angles, UserAngles,
        SL_P_WordDir, Dir
    );

    gSelWord[UserId] = SprLett_InitWord(Word, UserOrigin);
    if(!SprLett_BuildWord(gSelWord[UserId])){
        SprLett_RemoveWord(gSelWord[UserId]);
        gSelWord[UserId] = nullent;
        client_print(UserId, print_chat, "[Табличка] Не удалось создать надпись: недостаточно объектов или недоступен шрифт.");
        return;
    }
    client_print(UserId, print_center, "%l", "CMD_WORD_CREATED", Word);
    Menu_Main(UserId);
}

@Cmd_Charset(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new CharsetName[32];
    read_argv(NULL_ARG+1, CharsetName, charsmax(CharsetName));
    if(!SprLett_HasCharset(CharsetName)){
        client_print(UserId, print_chat, "[Табличка] Шрифт не найден. Выберите установленный шрифт в меню.");
        return;
    }
    new Previous[32];
    get_entvar(gSelWord[UserId], var_SL_WordCharset, Previous, charsmax(Previous));
    set_entvar(gSelWord[UserId], var_SL_WordCharset, CharsetName);
    if(!SprLett_RebuildWord(gSelWord[UserId])){
        set_entvar(gSelWord[UserId], var_SL_WordCharset, Previous);
        ReportBuildError(UserId);
    }
}

@Cmd_Write(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new NewWord[WORD_MAX_LENGTH];
    ReadCommandText(WRITE_CMD, NewWord, charsmax(NewWord));

    if(!SprLett_SetWordText(gSelWord[UserId], NewWord))
        client_print(UserId, print_chat, "[Табличка] Текст не изменён: недостаточно свободных объектов.");
    Menu_Main(UserId);
}

@Cmd_Save(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CHECK_WORD(UserId)

    if (!SprLett_SaveWord(gSelWord[UserId])) {
        ReportSaveError(UserId);
        return;
    }

    client_print(UserId, print_center, Lang("CMD_WORD_SAVED"));
}

@Cmd_Remove(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CHECK_WORD(UserId)

    if (!SprLett_UnSaveWord(gSelWord[UserId])) {
        ReportSaveError(UserId);
        return;
    }
    SprLett_RemoveWord(gSelWord[UserId]);
    gSelWord[UserId] = nullent;

    client_print(UserId, print_center, Lang("CMD_WORD_REMOVED"));
}

@Cmd_MarqueeToggle(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CHECK_WORD(UserId)

    new WordEnt = gSelWord[UserId];

    new Width = get_entvar(WordEnt, var_SL_MarqueeWidth) > 0 ? 0 : DEFAULT_MARQUEE_WIDTH;
    if(!SprLett_SetMarqueeWidth(WordEnt, Width)) ReportBuildError(UserId);

    Menu_Marquee(UserId);
}

@Cmd_MarqueeSetId(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new WordEnt = gSelWord[UserId];
    new marqueeId = read_argv_int(NULL_ARG+1);
    if(marqueeId < 0 || marqueeId >= 999999999) return;
    set_entvar(WordEnt, var_SL_MarqueeID, marqueeId);

    Menu_Marquee(UserId);
}

@Cmd_MarqueeSetWidth(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new width = read_argv_int(NULL_ARG+1);
    new WordEnt = gSelWord[UserId];

    if(!SprLett_SetMarqueeWidth(WordEnt, width)) ReportBuildError(UserId);

    Menu_Marquee(UserId);
}

@Cmd_MarqueeSetSpeed(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new Float:speed = read_argv_float(NULL_ARG+1);
    if(!(speed >= 0.0 && speed <= 1000.0)) return;

    new WordEnt = gSelWord[UserId];
    set_entvar(WordEnt, var_SL_MarqueeSpeed, speed);

    Menu_Marquee(UserId);
}

@Cmd_MarqueeSetText(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new WordEnt = gSelWord[UserId];

    new Text[WORD_MAX_LENGTH];
    ReadCommandText(MARQUEE_SETTEXT_CMD, Text, charsmax(Text), true);
    if(!SprLett_SetWordText(WordEnt, Text)) ReportBuildError(UserId);

    Menu_Marquee(UserId);
}

@Cmd_MarqueeResetOffset(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CHECK_WORD(UserId)

    new WordEnt = gSelWord[UserId];
    new width = get_entvar(WordEnt, var_SL_MarqueeWidth);
    if (width > 0) {
        new Float:StartOffset = Float:get_entvar(WordEnt, var_SL_MarqueeSpeed) > 0.0 ? float(width) : 0.0;
        set_entvar(WordEnt, var_SL_MarqueeOffset, StartOffset);
        SprLett_RefreshMarquee(WordEnt);
    }

    Menu_Marquee(UserId);
}

stock MarqueeEditor_Disable(const WordEnt){
    SprLett_SetMarqueeWidth(WordEnt, 0);
}

ReportSaveError(const UserId){
    new Path[PLATFORM_MAX_PATH];
    SprLett_GetSavesFile(Path, charsmax(Path));
    client_print(UserId, print_center, "%l", "CMD_SAVE_FAILED");
    client_print(UserId, print_console, "%l", "CMD_SAVE_FAILED_PATH", Path);
}

stock MarqueeEditor_TrimString(string[], maxlength){
    new len = strlen(string);
    for (new i = len - 1; i >= 0; i--){
        if (string[i] == ' ')
            string[i] = EOS;
        else
            break;
    }

    len = strlen(string);
    new start = 0;
    while (string[start] == ' ' && start < len)
        start++;

    if (start > 0)
        format(string, maxlength, "%s", string[start]);
}

@Cmd_SetStepEx(const UserId){
    CMD_CHECK_ACCESS(UserId)

    new CurValId = 0;
    new Float:CurStep = gMoveStep[UserId];
    for(new i = 0; i < sizeof MOVESTEP_VALUES; i++){
        if(CurStep < float(MOVESTEP_VALUES[i])){
            CurValId = i;
            break;
        }
        if(i == sizeof MOVESTEP_VALUES - 1){
            CurValId = 0;
        }
    }

    gMoveStep[UserId] = float(MOVESTEP_VALUES[CurValId]);
}

@Cmd_SetStep(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    new Float:Step = read_argv_float(NULL_ARG+1);
    if(Step >= 0.1 && Step <= 512.0) gMoveStep[UserId] = Step;
}

@Cmd_Offset(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 1)
    CHECK_WORD(UserId)

    new Float:Offset = get_entvar(gSelWord[UserId], var_SL_WordOffset);
    Offset += read_argv_float(NULL_ARG+1);
    if(!(Offset >= -512.0 && Offset <= 512.0)) return;
    set_entvar(gSelWord[UserId], var_SL_WordOffset, Offset);
    SprLett_RebuildWord(gSelWord[UserId]);
}

@Cmd_Move(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 3)
    CHECK_WORD(UserId)

    new Float:Origin[3];
    get_entvar(gSelWord[UserId], var_origin, Origin);
    Origin[0] += read_argv_float(NULL_ARG+1);
    Origin[1] += read_argv_float(NULL_ARG+2);
    Origin[2] += read_argv_float(NULL_ARG+3);
    for(new a; a < 3; a++){
        if(!(Origin[a] >= -8192.0 && Origin[a] <= 8192.0)){
            client_print(UserId, print_chat, "[Табличка] Координаты вне допустимого диапазона.");
            return;
        }
    }
    set_entvar(gSelWord[UserId], var_origin, Origin);
    SprLett_RebuildWord(gSelWord[UserId]);
}

@Cmd_Rotate(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 3)
    CHECK_WORD(UserId)

    new Float:Delta[3];
    Delta[0] = read_argv_float(NULL_ARG+1);
    Delta[1] = read_argv_float(NULL_ARG+2);
    Delta[2] = read_argv_float(NULL_ARG+3);

    new Float:Angles[3];
    get_entvar(gSelWord[UserId], var_angles, Angles);
    Angles[0] += Delta[0];
    Angles[1] += Delta[1];
    Angles[2] += Delta[2];
    for(new a; a < 3; a++){
        if(!(Angles[a] >= -36000.0 && Angles[a] <= 36000.0)) return;
    }
    set_entvar(gSelWord[UserId], var_angles, Angles);

    if(SprLett_RotateMode:get_entvar(gSelWord[UserId], var_SL_RotateMode) == SL_ROTATE_WORD)
        SyncWordDirWithAngles(gSelWord[UserId]);

    SprLett_RebuildWord(gSelWord[UserId]);
}

@Cmd_RotateMode(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 0)
    CHECK_WORD(UserId)

    new WordEnt = gSelWord[UserId];
    new PW, PH, PS;
    if(SprLett_GetPanel(WordEnt, PW, PH, PS)){
        client_print(UserId, print_chat, "[Табличка] Рамка поворачивается вместе с надписью. Уберите рамку для раздельного вращения букв.");
        return;
    }
    new SprLett_RotateMode:PrevMode = SprLett_RotateMode:get_entvar(WordEnt, var_SL_RotateMode);
    new SprLett_RotateMode:Mode = (PrevMode == SL_ROTATE_WORD) ? SL_ROTATE_LETTERS : SL_ROTATE_WORD;
    set_entvar(WordEnt, var_SL_RotateMode, _:Mode);

    if(PrevMode == SL_ROTATE_WORD)
        SyncWordDirWithAngles(WordEnt);
    if(Mode == SL_ROTATE_WORD)
        SyncWordDirWithAngles(WordEnt);

    SprLett_RebuildWord(WordEnt);

    new ModeMessageKey[32];
    if(Mode == SL_ROTATE_WORD)
        copy(ModeMessageKey, charsmax(ModeMessageKey), "CMD_ROTATE_MODE_WORD");
    else
        copy(ModeMessageKey, charsmax(ModeMessageKey), "CMD_ROTATE_MODE_LETTERS");
    client_print(UserId, print_center, "%l", ModeMessageKey);
}

@Cmd_Dir(const UserId){
    CMD_CHECK_ACCESS(UserId)
    CMD_CHECK_ARGC(UserId, 2)
    CHECK_WORD(UserId)

    new Float:Dir[3];
    get_entvar(gSelWord[UserId], var_SL_WordDir, Dir);
    Dir[0] += read_argv_float(NULL_ARG+1);
    Dir[1] += read_argv_float(NULL_ARG+2);
    set_entvar(gSelWord[UserId], var_SL_WordDir, Dir);
    SprLett_RebuildWord(gSelWord[UserId]);
}

@Cmd_Select(const UserId){
    CMD_CHECK_ACCESS(UserId)
    new Ent;
    get_user_aiming(UserId, Ent);
    
    if((Ent = SprLett_GetWord(Ent)) == nullent){
        Ent = FindWordByAim(UserId);
    }

    if(Ent == nullent){
        client_print(UserId, print_center, Lang("CMD_WORD_NOT_FOUND"));
        gSelWord[UserId] = nullent;
        return;
    }

    gSelWord[UserId] = Ent;

    new Word[WORD_MAX_LENGTH];
    get_entvar(gSelWord[UserId], var_SL_WordText, Word, charsmax(Word));
    client_print(UserId, print_center, "%l", "CMD_WORD_SELECTED", Word);
    return;
}





public client_disconnected(id){
    gSelWord[id] = 0;
    gConfirmDelete[id] = 0;
    gMoveStep[id] = 1.0;
}

public SprLett_WordRemoved(const WordEnt){
    for(new id = 1; id <= MaxClients; id++){
        if(gSelWord[id] == WordEnt) gSelWord[id] = 0;
        if(gConfirmDelete[id] == WordEnt) gConfirmDelete[id] = 0;
    }
}

ReportBuildError(const UserId){
    client_print(UserId, print_chat, "[Табличка] Изменение не выполнено: недостаточно свободных объектов. Прежнее состояние сохранено.");
}
